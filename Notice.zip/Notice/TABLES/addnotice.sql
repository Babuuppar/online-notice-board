-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2017 at 10:12 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `noticeboarddata`
--

-- --------------------------------------------------------

--
-- Table structure for table `addnotice`
--

CREATE TABLE `addnotice` (
  `Aid` int(15) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `target` varchar(20) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `requested` varchar(30) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addnotice`
--

INSERT INTO `addnotice` (`Aid`, `title`, `target`, `description`, `requested`, `approved`, `created`) VALUES
(8, 'About Extra class on Advanced web', 'II MCA', '<strong>&nbsp;&nbsp; On,29/5/17 an extra class is scheduled,Notice to everybody.<img src="tinymce/plugin/tinymce/plugins/emoticons/img/smiley-smile.gif" alt="smile" /></strong></li>\n</ul>', 'Ramakrishna Reddy', 5, '2017-06-04 10:06'),
(7, 'hi', 'I MCA', '<p>jkjjkkk gfdgfdgdf fgdddddddddddddddkkjkkkkkkkkkkkkkkkk</p>', 'Ramakrishna Reddy', 1, '2017-06-04 10:08'),
(9, 'Results of examination 2017', 'TOALL', 'Results are announced please everone chech your results.', 'Ramakrishna Reddy', 1, '2017-06-04 10:26'),
(10, 'Hello friends', 'II MCA', 'Hi dfsdjfffffffffffffffffffffffffffff hjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj dddddddddddddddddddddddddddddddddddds dshddddddddddddddddddddddddddddj', 'Ramakrishna Reddy', 1, '2017-06-04 10:46'),
(11, 'Hello', 'I MCA', '<img src="https://www.google.co.in/search?q=me+image&amp;source=lnms&amp;tbm=isch&amp;sa=X&amp;ved=0ahUKEwih_KGiuaTUAhWBO48KHSrHB50Q_AUIBigB&amp;biw=1607&amp;bih=792#imgrc=IA0Qx8-yYU-fNM:&amp;spf=1496588141266" alt="ME" />', 'Ramakrishna Reddy', 5, '2017-06-04 11:06'),
(13, 'nnn', 'I MCA', '<p>ghhg</p>', 'Simha A', 1, '2017-06-04 11:26'),
(14, 'Regarding Library card issual', 'I MCA', '<p>All I Year Students are requested to borrow library books on the scheduled date i.e on 5/6/217</p>', 'Simha A', 2, '2017-06-05 11:06'),
(15, 'Regarding Library books issual', 'II MCA', '<p>Hello,all 2nd year students are requested to burrow thier books in library on or befor 12/6/2017 12pm.</p>', 'Simha A', 1, '2017-06-05 11:06'),
(16, 'Good morning', 'I MCA', '<p>dssssssssss</p>', 'Simha A', 1, '2017-06-05 03:06'),
(44, 'fgdf', 'I MCA', '<p>fdgdfg</p>', 'Simha A', 1, '2017-06-05 06:06'),
(43, 'Babu', 'I MCA', '<p>dfsdfsdf</p>', 'Simha A', 1, '2017-06-05 06:06'),
(84, 'fdsdfsd', 'II MCA', '<div style="text-align: left;">dsffffffffffffffffffffffffff</div>', 'Ramakrishna Reddy', 1, '2017-06-08 08:06'),
(85, 'ddfsdfs', 'II MCA', '<p>ddddddddddddddddddddddddddddd&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 06/08/2017</p>', 'Ramakrishna Reddy', 1, '2017-06-08 08:06'),
(78, 'Hdhdjhghbb', 'II MCA', '<p><strong>hjhhhj</strong></p>', 'Simha A', 2, '2017-06-07 06:06'),
(79, 'Hdhdjhghbb', 'II MCA', '<p>&nbsp;bavgsghdhh</p>', 'Ankibabu', 1, '2017-06-07 06:06'),
(80, 'fgfffffffffffffffffffff', 'II MCA', '<h1>gtfgfgfgfgfgfg</h1>', 'Ramakrishna Reddy', 5, '2017-06-08 07:06'),
(82, 'gfhfgh', 'II MCA', '<h3><strong><em>hfghghfhffffffffffffffffffffffffffffff&nbsp; hghhhhhhhhhhhhhhhhhhhf</em></strong></h3>', 'Ramakrishna Reddy', 1, '2017-06-08 08:06'),
(83, 'fgfgfdd', 'II MCA', '<div><span style="color: #800080;"><em>dsfffffffffffffffffffffffffffff ddddddddddddddddddddddd</em></span></div>', 'Ramakrishna Reddy', 1, '2017-06-08 08:06'),
(76, 'sdsddfd', 'I MCA', '', 'Ramakrishna Reddy', 1, '2017-06-06 09:06'),
(73, 'dfdgd', 'I MCA', '<p>dfgdfgdfg</p>', 'Ramakrishna Reddy', 1, '2017-06-06 08:06'),
(74, 'fgdfg', 'I MCA', '<p>fgfdgdfg</p>', 'Ankibabu', 2, '2017-06-06 08:06'),
(77, 'hhhhhhhhhhhhhhhh', 'II MCA', '<p>jlkjjjjjjjjjjjjjjjjjjjj</p>', 'Simha A', 1, '2017-06-06 10:06'),
(75, 'ghfggggg', 'I MCA', '<p>gffffffffffffh</p>', 'Ramakrishna Reddy', 1, '2017-06-06 09:06'),
(86, 'Placement training 2017', 'II MCA', '<p>&nbsp;The placement training has been scheduled from 12/07/2017 to 17/07/2017 .Everyone are requested to present on or befor 9am.</p>', 'Simha A', 4, '2017-06-10 07:06'),
(87, 'About Extra class on Advanced web', 'TOALL', '<p>Aweb extra class been planned on 17/7/2017 at 2.30-3.30pm.</p>', 'Simha A', 4, '2017-06-10 07:06'),
(88, 'gdfgd', 'II MCA', '<p>ddddddddddddd</p>', 'Simha A', 1, '2017-06-10 07:06'),
(89, 'fgfg', 'II MCA', '<p>ggggggggggggggggggggg ffffffffffffffffffffffffffff fggggggggg hghgh hfhf fffffffff</p>', 'Simha A', 1, '2017-06-10 07:06'),
(90, 'bfffffffff', 'II MCA', '<p>cbbbbbbbbbbb</p>', 'Simha A', 1, '2017-06-10 08:06'),
(91, 'dfdddd', 'II MCA', '<p>dfffffffffffffffffffff</p>', 'Simha A', 5, '2017-06-10 08:06'),
(92, 'gfhfghfgh', 'II MCA', '<p><video poster="fggggggggggggggg" controls="controls" width="188" height="94">\r\n<source src="nggff" />\r\n<source src="ghhhhhhhhf" /></video></p>', 'Ramakrishna Reddy', 5, '2017-06-10 09:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addnotice`
--
ALTER TABLE `addnotice`
  ADD PRIMARY KEY (`Aid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addnotice`
--
ALTER TABLE `addnotice`
  MODIFY `Aid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
