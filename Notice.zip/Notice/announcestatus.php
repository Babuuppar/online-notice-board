  <html lang="en"><head>
	<meta charset="utf-8">
	<title>jQuery UI Tabs - Default functionality</title>
	    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/Notifications.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
</head>
<body>
 <?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$status="";
$sql="select created,approved,target,title,description from register r,addnotice a where CONCAT(r.fname,' ',r.lname)=a.requested and uid='$userid'";
$result=mysqli_query($bd,$sql);
if ($result->num_rows > 0)	
{
  while($row=mysqli_fetch_array($result,MYSQL_NUM))
  {
    if($row[1]==='1')
	{
		$status="<a class='btn  btn-lg' style='color:#659D32;'><i class='fa fa-check fa-fw'></i> <span class='network-name'>Approved</span></a>";
	}
	else if($row[1]==='0')
	{
		$status="<a class='btn  btn-lg' style='color:#ccccc00;'><i class='fa fa-level-down fa-fw'></i> <span class='network-name'>In pending</span></a>";
	}
	else if($row[1]==='3')
	{
		$status="<a class='btn  btn-lg' style='color:skyblue;'><i class='fa fa-level-down fa-fw'></i> <span class='network-name'>In pending</span></a>";
	}
	else if($row[1]==='2')
	{
		$status="<a class='btn  btn-lg' style='color:red;'><i class='fa fa-ban fa-fw'></i> <span class='network-name'>Rejected</span></a>";
	}
	else if($row[1]==='4')
	{
		$status="<a class='btn  btn-lg' style='color:#7171C6;'><i class='fa fa-check fa-fw'></i> <span class='network-name'>sent by you</span></a>";
	}
	{
			 print("<div class='info'><h5 align='left'>$row[3]  <h5 align='right'>TARGET:$row[2]</h5></h5><h4 align='right'>$status POSTED ON:$row[0]</h4><br/>
	         </div>");
		
	}
	//print("<div class='row'><div class='col-md-12'><div class='testimonial-section'> <div class='testimonial'><p>$row[1]$row[3]<div calss='testimonial-people'><form action='accept.php' name='$row[0]' method='post'><input type='submit' value='Hold' name='$row[0]'/><input type='submit' value='Reject' name='$row[0]'/><input type='submit' value='Accept' name='$row[0]'/></form></div> <h5 align='right'>By:$row[4]</h5></div></div></div></div>");
  }
}
else
{
	print("<h3 align=center>No Requests are available!!!</h3>");
}
?>
<?php if(isset($_GET['modal']))
print("<div  class='modal fade' id='myModal' role='dialog' aria-labelledby='myModalLabel'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <button class='close' aria-label='Close' type='button' data-dismiss='modal'><span aria-hidden='true'>×</span></button>
        <h4 class='modal-title' id='myModalLabel'>Modal title</h4>
      </div>
      <div class='modal-body'>
        ...
      </div>
      <div class='modal-footer'>
        <button class='btn btn-default' type='button' data-dismiss='modal'>Close</button>
        <button class='btn btn-primary' type='button'>Save changes</button>
      </div>
    </div>
  </div>
</div>");
?>
<!-- Modal -->
</body></html>