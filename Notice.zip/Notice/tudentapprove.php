  <html lang="en"><head>
	<meta charset="utf-8">
	<title>jQuery UI Tabs - Default functionality</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
	<script>
	$(function() {
		$( "#tabs" ).tabs();
	});
	</script>
</head>
<body>

<div id="tabs" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
	<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
		<li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-1" aria-labelledby="ui-id-1" aria-selected="false" aria-expanded="false"><a href="#tabs-1" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-1">Tab 1</a></li>
		<li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="tabs-2" aria-labelledby="ui-id-2" aria-selected="true" aria-expanded="true"><a href="#tabs-2" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-2">Tab 2</a></li>
	</ul>
	<div id="tabs-1" aria-labelledby="ui-id-1" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="true" style="display: none;">
<table border="" cellpadding="5%" cellspacing="5%">  
 <tr bgcolor="lightblue"><th>USER ID<th>NAME<th>USERTYPE</tr>
 <?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$sql="SELECT *from register WHERE verified=0";
$result=mysqli_query($bd,$sql);
while($row=mysqli_fetch_array($result,MYSQL_NUM))
 {
    print("<a href=''><tr><td>$row[3]</td><td>$row[0].$row[1]</td><td>$row[2]</td></tr></a>");
 }

//exit();
?>
</table>  
	</div>
	<div id="tabs-2" aria-labelledby="ui-id-2" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="false" style="display: block;">
    <table border="" cellpadding="5%" cellspacing="5%">  
 <tr bgcolor="lightblue"><th>USER ID<th>NAME<th>USERTYPE</tr>
 <?php
include("config.php");
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$sql="SELECT *from register WHERE verified=0";
$result=mysqli_query($bd,$sql);
while($row=mysqli_fetch_array($result,MYSQL_NUM))
 {
    print("<a href=''><tr><td>$row[3]</td><td>$row[0].$row[1]</td><td>$row[2]</td></tr></a>");
 }

//exit();
?>
</table>
	</div>
</div>

</body></html>












