
<?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$AI=array_keys($_POST);
$action=$_POST[$AI[0]]; 
//print($action);
$sql="SELECT *from register where uid='$AI[0]'";
$result=mysqli_query($bd,$sql);
if ($result->num_rows > 0)	
{
	if($action==="Accept")
	{
		$sql1="UPDATE register set verified=1 where uid='$AI[0]'";
        $result1=mysqli_query($bd,$sql1);
	}
	
	if($action==="Reject")
	{
		$sql2="UPDATE register set verified=2 where uid='$AI[0]'";
        $result2=mysqli_query($bd,$sql2);
	}
	
	if($action==="Hold")
	{
	   $sql3="UPDATE register set verified=3 where uid='$AI[0]'";
       $result3=mysqli_query($bd,$sql3);
	}
	if($action==="UnHold")
	{
	   $sql3="UPDATE register set verified=1 where uid='$AI[0]'";
       $result3=mysqli_query($bd,$sql3);
	}
	
	$link="Location:".$_SESSION["link"];
	header($link);
}
?>

