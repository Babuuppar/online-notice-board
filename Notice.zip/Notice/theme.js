(function($){
	
	//== Navigation
	//=============================================/
	var $mainNav    = $('.main-nav').children('ul');
	$mainNav.on('mouseenter', 'li', function(){
		var $this = $(this),
			$subMenu = $this.children('ul.dropdown');
		$subMenu.stop(true, true).slideDown(300);
	}).on('mouseleave', 'li',function(){
		$(this).children('ul.dropdown').stop(true, true).slideUp(100);
	});
	
	var $handle = $('#main-nav button');
	var $handleIcon = $('#main-nav button i');
	var $toggleNav = $('#main-nav #toggleNav');	
	$handle.click(function(){
		$toggleNav.slideToggle('slow');
		if($handleIcon.hasClass('fa-bars')){
			$handleIcon.removeClass('fa-bars');
			$handleIcon.addClass('close')
		}else {
			$handleIcon.removeClass('close');
			$handleIcon.addClass('fa-bars')
		}
	});
	
	//== Tabs
	//=============================================/
	$("#contentzz .tab_content").hide(); // Initially hide all content
	$("#tabszz li:first").attr("id","current"); // Activate first tab
	$("#contentzz .tab_content:first").fadeIn(); // Show first tab content
	$('#tabszz a').click(function(e) {
		e.preventDefault();
		if ($(this).closest("li").attr("id") == "current"){ //detection for current tab
			return
		}
		else {
			$("#contentzz .tab_content").hide(); //Hide all content
			$("#tabszz li").attr("id",""); //Reset id's
			$(this).parent().attr("id","current"); // Activate this
			$('#' + $(this).attr('name')).fadeIn(); // Show content for current tab
		}
	});
	
	//== ToTop
	//=============================================/
	$(window).scroll(function() {
		if($(this).scrollTop()!= 0){
			$('#toTop').fadeIn();	
		} else {
			$('#toTop').fadeOut();
		}
	});
	$('#toTop').click(function() {
		$('body,html').animate({scrollTop:0},500);
	});
	
	
	
})(jQuery);