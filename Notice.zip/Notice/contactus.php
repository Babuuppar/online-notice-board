
<!DOCTYPE html>
<html class="no-js">
<head>
    
    <title>contact</title>
    <!--/// Plugin //-->
    <link rel="stylesheet" type="text/css" href="jquery-ui.css" media="all">
    <!--/// Stylesheets //-->
    <link rel="stylesheet" type="text/css" href="style.css" media="all">
	<link href="responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />  
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
	
    <!--/// CORE scripts always load first //-->
    <script src="jquery.js"></script>
</head>	
<body onLoad="document.getElementById('link').click();">
<section class="contact contact-section" id="contact" style="width: 1066px; padding-left: 111px;">
        <div class="container" style="width: 1024px;" row"="">
		<div class="row" style="width: 896px;">
         
                <div class="col-lg-12">
                    <div class="section-title text-center wow fadeInDown" data-wow-delay="50ms" data-wow-duration="2s">
                        <h2 align="center">Contact With Us</h2></br>
                        <p>Post your Opinion and Suggestion here</p></br>
                    </div>
                </div>

            </div>
                 <div class="row" style="width: 1096px;">           
			      <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" action="contactmail.php" method="post">
                        <div class="row">
                            <div class="col-md-6 wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="2s">
                                <div class="form-group waves-effect">
                                    <input class="form-control" id="name" name="name" required type="text" placeholder="Your Name *" data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group waves-effect">
                                    <input class="form-control" id="email" name="email" required type="email" placeholder="Your Email *" data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group waves-effect">
                                    <input class="form-control" id="phone" required name="phone" type="tel" placeholder="Your Phone *" data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6 wow fadeInRight" data-wow-delay="600ms" data-wow-duration="2s">
                                <div class="form-group waves-effect">
                                    <textarea class="form-control" id="message" name="message" required placeholder="Your Message *" data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
								  <div class="form-group waves-effect">
                                   </br></br><a href="index.html"><button type="button" class="btn btn-previous"  type="submit" >Back</button></a>
								   <input type="submit" value="Send"> 
                                </div>
								
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
   <script type="text/javascript" src="jquery.form.js"></script><!-- Social Icons -->	
    <!--/// PLUGINS_DEPENDENCY always load after CORE but before PLUGINS //-->
    <script src="theme.js"></script>
	<script src="smoothscroll.js" type="text/javascript"></script>
	<script src="responsive-tabs.min.js" type="text/javascript"></script>
</body>
</html>