  <?php 
									
								if(!isset($_SESSION))
								{
									session_start();
								} 	
								?>
<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BMSCE</title>
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
        <script>
		H5F.listen(window,"load",function () 
		{
		      H5F.setup(document.getElementById("signup"));
		},false);
</script>
    </head>
    <body>
        <!-- Top content -->
        <div class="top-content">
            <div class="container">  
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 text">
                        <h1>NOTICE <strong>BOARD</strong></h1>
                        <div class="description">
                       	    <p>
                               <a href="http://www.bmsce.ac.in"><strong>VISIT BMSCE WEBSITE</strong></a>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3 form-box">
                    	<form role="form" action="Login.php" method="POST" class="f1" id="signup">
                    		<h3>LOGIN</h3>
                    		<div class="f1-steps" style="padding-left:155px;">
                    			<div class="f1-progress">
                    			    <div class="f1-progress-line" data-now-value="16.66" data-number-of-steps="1" style="width: 156.66%;"></div>
                    			</div>
                    			<div class="f1-step active">
                    				<div class="f1-step-icon"><i class="fa fa-user"></i></div>
                    				<p>Login</p>
                    			</div>
                    		</div>
							  <fieldset>
							  <h4>Enter login details:</h4>
							  <div class="form-group">					
                              <label class="sr-only" for="userid">user Id*</label> 
                              <input type="text" id="userid" name="userid" placeholder="Enter your Id...(usn or EmpId)" class="f1-first-userid form-control" id="f1-first-userid" required pattern="[0-90-9A-ZA-Z0-90-9A-ZA-ZA-Z0-90-9]{10}" title="e.g:1BM15MCA10 or BMSEMP0001">
                              </div>
							  <div class="form-group">
							  <label class="sr-only" for="password">password *</label> 
							  <input type="password" id="upass" name="password" placeholder="Enter your password..." class="f1-first-password form-control" id="f1-first-password" title="Enter valid Password!" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*" required>
		                      </div>
							  <div class="form-group">
							  <a href="indexmain.php"><button type="button" class="btn btn-submit">Home</button></a>
			                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Login"/>
                              </div>
							  <center>
							  <?php   
									if(isset($_SESSION['message']))
									{
										print($_SESSION['message']);
									    unset($_SESSION['message']);
									}
									if(isset($_SESSION['registered']))
									{
										print($_SESSION['registered']);
										unset($_SESSION['registered']);
										require('testmail.php');
										
									}
									
								 ?>
							 </center>
                              </fieldset>
					</form>
                </div>
                    
            </div>
        </div>
		</div>
        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/retina-1.1.0.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>