-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2017 at 03:50 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `noticeboarddata`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `usertype` varchar(30) DEFAULT NULL,
  `uid` varchar(15) DEFAULT NULL,
  `Designation` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pword` varchar(25) DEFAULT NULL,
  `verified` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`fname`, `lname`, `usertype`, `uid`, `Designation`, `email`, `pword`, `verified`) VALUES
('Barath', 'K', 'student', '1BM16MCA10', 'Lateral', 'barath.bms@gmail.com', 'Babu@123', 1),
('Ankith', 'AV', 'student', '1BM15MCA03', 'Regular', 'ankithbms@gmail.com', 'Bmsce@Babu', 1),
('Babu', 'Allu', 'student', '1BM16MCA11', 'Lateral', 'babuallu.bmsce@gmail.com', 'Babu@123', 1),
('Ankith', 'AV', 'student', '1BM15MCA02', 'Regular', 'ankithbms@gmail.com', 'Bmsce@Ankith123', 1),
('Ramakrishna', 'Reddy', 'staff', 'BMSEMP0002', 'HOD', 'ramakrishna.mca@bmsce.co.in', 'Ramakrishna@bmsce', 1),
('Babu', 'A', 'student', '1BM16MCA64', 'Lateral', 'ankithbms@gmail.com', 'Bmsce@Babu', 0),
('Harsha', 'A', 'student', '1BM16MCA14', 'Regular', 'babugsc01@gmail.com', 'Bmsce@Babu', 0),
('Babu', 'A', 'student', '1BM14MCA02', 'Regular', 'ankithbms@gmail.com', 'Bmsce@Babu', 0),
('Akshay', 'S', 'student', '1BM14MCA03', 'Lateral', 'akshay.bms@gmail.com', 'Bmsce@Babu', 0),
('Nischal', 'K', 'student', '1BM15MCA30', 'Lateral', 'nischal.bms@gmail.com', 'Bmsce@Babu', 0),
('Jathin', 'Prasad', 'student', '1BM14MCA05', 'Lateral', 'babugsc01@gmail.com', 'Bmsce@Babu', 1),
('Ankith', 'fgf', 'staff', 'BMSEMP0010', 'Assistant professor', 'ankithbms@gmail.com', 'Bmsce@Babu', 1),
('Simha', 'A', 'staff', 'BMSEMP0011', 'Assistant professor', 'ankithbms@gmail.com', 'Bmsce@Babu', 1),
('Gopal', 'Shankar', 'student', '1BM16MCA88', 'Regular', 'gopalshankar@gmail.com', 'Bmsce@Babu', 0),
('Uppendra', 'Rao', 'student', '1BM15MCA60', 'Lateral', 'uppendra.bms@gmail.com', 'Babu@123', 1),
('Bahanu', 'prakash', 'staff', 'BMSEMP0025', 'Associate professor', 'bhanuprakash.bms@gmail.com', 'Babu@123', 1),
('Amarnath', 'SA', 'staff', 'BMSEMP0018', 'Assistant professor', 'amar.bmsce@gmail.com', 'Babu@123', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
