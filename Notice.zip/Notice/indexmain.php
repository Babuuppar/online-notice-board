<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BMSCE</title>
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
		<link rel="stylesheet" href="assets/sidenotice.css" type="text/css"/>
		<script type="text/javascript" src="form.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script>
		function validateusn()
		{
		  //alert("USN is not exist!!");
		  var usn=document.getElementById('usn').value;
		  var cdate=new Date();
		  var cyr=cdate.getFullYear();
		  var cmnth=cdate.getMonth()+1;
		  //alert(usn.substr(3,2).toString());
		  //alert(usn.substr(3,2));
		  //alert(cyr.toString().substr(2,2));
		 if((usn.substr(3,2).toString()===cyr.toString().substr(2,2).toString())&&(cmnth<8))
		  {
		      alert("USN not generated yet!!");
			  window.location.href='index.html';
		  }
		  else if(usn.substr(3,2)>cyr.toString().substr(2,2))
		  {
		      alert("USN is not exist!!");
              window.location.href='indexmain.php';
		  }
		}
		H5F.listen(window,"load",function () 
		{
		      H5F.setup(document.getElementById("signup"));
		},false);
       var i=1;
      function AddTextBox()
      {
         if(document.getElementById('user').value=="student")
          {
            var div=document.createElement('div')
            div.innerHTML ='<label class="sr-only" for="f1-usn">USN</label>'
	        div.innerHTML='<input type="text" name ="usn" id="usn" required pattern="[0-90-9A-ZA-Z0-90-9A-ZA-ZA-Z0-90-9]{10}" placeholder="Enter usn" title="e.g:1BM15MCA01" onblur="validateusn()"/>'+'<p class="validation01">'+'<span class="invalid">Enter a valid usn!! e.g.1BM15MCA10!!'+'</span>'+'<span class="valid">Your usn might be valid!'+'</span>'+'</p>'+'<br/>'+'<br/>'+'<input type="radio" id="stud" value="Regular" name="sel" checked="checked">Regular'+'<input type="radio" value="Lateral" id="stud" name="sel">Lateral'+'<input type="radio" value="YB" id="stud" name="sel">Re-appear';
            document.getElementById('kids').appendChild(div);
         }
  
       if(document.getElementById('user').value=="staff"||document.getElementById('user').value=="hod")
       {
            if(i<=1)
	         {
	           i++;
	           var div = document.createElement('div');
               div.innerHTML='<label class="sr-only" for="f1-staffid">staffid'+'</label>'
	           div.innerHTML='<input type="text" id="empid" required pattern="[A-ZA-ZA-ZA-ZA-ZA-Z0-90-90-90-90-9]{10}" name="staffid" placeholder="Your Id..." class="f1-first-staffid form-control" title="e.g:BMSEMP0001">'+'<p class="validation01">'+'<span class="invalid">Enter a valid staffid!! e.g:BMSEMP0001!!'+'</span>'+'<span class="valid">Your Id might be valid!'+'</span>'+'</p>'+'<br/>'+'<br/>'+'<select name="designation" id="disgn" data-toggle="button">'+'<option value="HOD">HOD'+'</option>'+'<option  value="Associate professor">Associate Professor'+'</option>'+'<option  value="Assistant professor">Assistant Professor'+'</option>'+'</select>';
               document.getElementById('kid1').appendChild(div);
	         }
       } 
      removeText();
     }
function removeText()
{
  if(document.getElementById('user').value=="student")
  {
    var div = document.getElementById('kid1');
    document.getElementById('stud').display="block";	
	while(div.hasChildNodes())
    document.getElementById('kid1').removeChild(div.lastChild);
	i--;
  }
  if(document.getElementById('user').value=="staff")
  {
    var studtype=document.getElementById('stud').display="none";
    var div = document.getElementById('kids'); 
    while(div.hasChildNodes())	
    document.getElementById('kids').removeChild(div.lastChild);
  }
 if(document.getElementById('user').value=="hod")
  {
    document.getElementById('stud').display="none";
	var div = document.getElementById('kids'); 
    while(div.hasChildNodes())	
    document.getElementById('kids').removeChild(div.lastChild);
  }

  //document.getElementById('kids').removeChild(div.parentNode);
}
</script>
    </head>
    <body>
		<!-- Top menu -->
		<nav class="navbar navbar-inverse navbar-no-bg" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#top-navbar-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html">Notice Board</a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="top-navbar-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<span class="li-text">	
							</span> 
							<a href="#"><strong></strong></a> 
							<span class="li-text">
							</span> 
							<span class="li-social">
									<button type="button" class="btn btn-next" data-toggle="modal" data-target="#myModal1">ADMIN</button>
									<a href="contactus.php"><button type="button" class="btn btn-next" data-toggle="modal" data-target="contactus.php">CONTACT US</button></a>
									
							</span>
						</li>
					</ul>
				</div>
				<h1 align="center">NOTICE <strong>BOARD</strong></h1>
                   <div class="description">
                       	<p>
                            <a href="http://www.bmsce.ac.in"><strong>VISIT BMSCE WEBSITE</strong></a>
                        </p>
                   </div>
			</div>
		</nav>
        <!-- Top content -->
<div class="container-fluid paddingReset" style="height: 0px;">
<div class="col-lg-12 col-md-12 col-xs-12 paddingReset" style="height:0px;">
<div class="col-lg-3 col-md-4 col-xs-12 sidebar">
<div class="cal_container" style="height: 402px;"><div class="nano list_view has-scrollbar" id="about">
<div tabindex="0" class="nano-content" style="right: -17px;">
<div class="upcoming_events cal-events">
 <i class="fa fa-fw fa-bullhorn"></i>
 <div class="h4 uppercase">Notice board</div> 
<?php 	include("config.php");
                        
                          mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
                          $sql="SELECT *FROM addnotice WHERE target='TOALL'";
                          $result=mysqli_query($bd,$sql);
                          while($row=mysqli_fetch_array($result))
						  {
							  print("<div class=cc_event><strong><p>$row[1]</p></strong><div class=text-muted cc_event_info small-text margin-top-xs><p>$row[3]</p></div><h6 align=right>by <a href=/users/admin>Admin</a>  at <p>$row[6]</p></div>");
						  }
                          print("</div></div>");
?>  
</div>

</div></div>

</div></div>

</div>
         <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3 form-box" style="padding-top: 0px;">
                    	<form role="form" action="Register.php" method="POST" class="f1" id="signup">

                    		<h3>Register To Our App</h3>
                    		<p>Fill in the form to get instant access</p>
                    		<div class="f1-steps">
                    			<div class="f1-progress">
                    			    <div class="f1-progress-line" data-now-value="16.66" data-number-of-steps="3" style="width: 16.66%;"></div>
                    			</div>
                    			<div class="f1-step active">
                    				<div class="f1-step-icon"><i class="fa fa-user"></i></div>
                    				<p>about</p>
                    			</div>
                    			<div class="f1-step">
                    				<div class="f1-step-icon"><i class="fa fa-key"></i></div>
                    				<p>account</p>
                    			</div>
                    		</div>
							
							  <fieldset>
							  <h4>Tell us who you are:</h4>
							  <div class="form-group">
                              <label class="sr-only" for="firstname">First Name *</label> 
                              <input type="text" id="firstname" name="firstname" placeholder="First Name" required pattern=".{4,15}" /><br/><br/>
                              <label class="sr-only" for="lastname">Last Name *</label> 
                              <input type="text" id="lastname" name="lastname" placeholder="Last Name" required pattern=".{1,15}"/>
							  </div>
							  <div class="form-group">
                                    <label class="sr-only" for="f1-about-yourself">About yourself</label>
									<select name="user" id="user" data-toggle="button"  onchange="AddTextBox();">
									<option  selected hidden value="title">Choose one</option>
                                    <option  value="staff">Staff</option>
                                    <option  value="student">Student</option>
                                    </select><br/><br/>
									<div id="kids">
                                    		 
                                   </div>
								   <div id="kid1">
								   </div>
							  <div class="f1-buttons">
                              <button type="button" class="btn btn-next" onclick="validateusn()">Next</button>
                              </div>
                              </fieldset>
							  <fieldset>
							  <h4>Set up your account:</h4>
							  <div class="form-group">
     <label class="sr-only" for="email">Email *</label> 
     <input type="email" id="email" name="email" placeholder="Email id..." title="Please enter a valid email" required />
     <p class="validation01">
      <span class="invalid">Please Enter a valid email address e.g. bmsce@example.com</span>
      <span class="valid">Your email address is now valid it seems!</span>
     </p>
	 </div>
	  <div class="form-group">
     <label class="sr-only" for="tel">Mobile *</label> 
     <input type="tel" id="tel" name="tel" pattern="\d{10}" placeholder="Mobile Number.." required />
     <p class="validation01">
      <span class="invalid">No spaces or brackets e.g. 9999999999</span>
      <span class="valid">Your mobile number is valid!</span>
     </p>
	 </div>
	  <div class="form-group">
	 <label class="sr-only" for="password">Password *</label>
     <input id="password" name="password" type="password" placeholder="Password.." title="Minimum 8 characters, one number, one uppercase and one lowercase letter" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*" required /> 
     <p class="validation01">
      <span class="invalid">Minimum 8 characters, one number, one uppercase letter and one lowercase letter</span>
      <span class="valid">Your password meets our requirements, thank you.</span>
     </p>
	 </div>
	  <div class="form-group">
	 <label class="sr-only" for="password">Repeat Password *</label>
     <input id="password" name="password" type="password" placeholder="Repeat password..." title="Minimum 8 characters, one number, one uppercase and one lowercase letter" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*" required /> 
     <p class="validation01">
      <span class="invalid">password must be same as previous!</span>
     </p>
	 </div>
	 <div class="f1-buttons">
	 <div class="modal-footer">
	 <button type="button" class="btn btn-previous">Back</button>
     <input type="submit" value="Register"/>
     </div>
     </div>
  </fieldset>
                </form>
						<button type="button" class="btn btn-next" data-toggle="modal" data-target="#myModal">ALREADY A USER?</button>
                </div>
                    
            </div>
        </div> 
<!-- Modal -->	
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h5 class="modal-title" >SIGN-IN</h5>
        </div>
        <div class="modal-body">
		<form action="Login.php" method="POST" class="f1">
		  <div class="form-group">
		    <input type="text" id="userid" name="userid" placeholder="Enter your Id...(usn or EmpId)" class="f1-first-userid form-control" id="f1-first-userid" required pattern="[0-90-9A-ZA-Z0-90-9A-ZA-ZA-Z0-90-9]{10}" title="e.g:1BM15MCA10 or BMSEMP0001">
		  </div>         
		 <div class="form-group">
			<input type="password" id="upass" name="password" placeholder="Enter your password..." class="f1-first-password form-control" id="f1-first-password" title="Enter valid Password!" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*" required>
		  </div>
		 <div class="modal-footer">
		    <button type="button" class="btn btn-next" data-dismiss="modal">Close</button>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Login"/>
        </div>
		</form>
        </div>
      </div>
 
    </div>
  </div>
<!-- End of Modal1 -->
	<!-- Modal -->	
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h5 class="modal-title" >SIGN-IN</h5>
        </div>
        <div class="modal-body">
		<form action="Login.php" method="POST" class="f1" name="admin">
		 <div class="form-group">
		    <input type="text" id="userid" name="userid" placeholder="Enter your Id..." class="f1-first-userid form-control" id="f1-first-userid" required pattern=".{4,30}" title="e.g:Useridmust be greater than 4 less than 30 characters!">
        </div>
		<div class="form-group">           
		   <input type="password" id="pass" name="password" placeholder="Enter your password..." class="f1-first-password form-control" id="f1-first-password" title="Enter valid Password!" required>
		 </div>
		 <div class="modal-footer">
		    <button type="button" class="btn btn-next" data-dismiss="modal">Close</button>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Login" name="admin"/>
        </div>
		</form>
        </div>
      </div>
    </div>
  </div>
<!-- End of Modal1 -->
        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/retina-1.1.0.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->  
	</div>
	<footer id="main_footer">
              	<div class="container row">
				<div class="social-icon">
				<div class="col-md-4">
					<ul class="social-network">
						<li><a href="https://www.facebook.com/search/top/?q=department%20of%20computer%20applications" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="https://www.linkedin.com/school/15114113/" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
					</ul>	
				</div>
			</div>
            	<div class="span_1_of_2">
                	&copy; Copyrights 2017. All rights reserved.
                </div>
            	<!--<div class="span_1_of_2">
                	<div align="right">Designed By: <a href="http://www.webstreaks.com/" target="_blank">Webstreaks.com</a></div>
                </div>-->
            </div>
     </footer>  
</body>
</html>