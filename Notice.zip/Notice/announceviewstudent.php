  <html lang="en"><head>
	<meta charset="utf-8">
	<title>Announcements</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="assets/css/Notifications.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
	<script>
	$(function() {
		$( "#tabs" ).tabs();
	});
	</script>
</head>
<body>
<div id="tabs" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
	<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
		<li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-1" aria-labelledby="ui-id-1" aria-selected="false" aria-expanded="false">
		<a href="#tabs-1" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-1">STUDENT</a></li>
	</ul>
	<div id="tabs-1" aria-labelledby="ui-id-1" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="true" style="display: none;">
<table border="" cellpadding="5%" cellspacing="5%">  
 <?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$sql1="SELECT *from register where uid='$userid' and Designation='lateral'";
$result1=mysqli_query($bd,$sql1);
$rs=$result1->num_rows;
function findyear($usn)
{
	$y=substr($usn,3,2);
	$cy=substr(date("Y"),2,2);
	$month=date("m");
	if(($cy-$y)<=3 && $y<=$cy)
	{
		if(($cy===$y &&($month>=6 && $month<=12))||(($cy-$y===1) && $month>=1 && $month<=5))
		{
			if($GLOBALS['rs']>=1)
			{
				return "II MCA";
			}
			else
			   return "I MCA";
		}
		else if(($cy-$y===1 &&($month>=5 && $month<=11))||(($cy-$y===2) && $month<=7))
		//else if(($cy-$y===1||($cy-$y===2)&&($month>1&&$month<=7)))
		{
			if($GLOBALS['rs']>=1)
			{
				return "III MCA";
			}
			return "II MCA";
		}
		else if(($cy-$y===2 &&($month>=8 && $month<=12))||(($cy-$y===3) && $month<=7))
		//else if((($cy-$y===2)||(($cy-$y===2))&&($month>7&&$month<=2)))
		{
			return "III MCA";
		}
	}
}
$year=findyear($userid);
print($year);
$_SESSION['year']=$year;
$sql="SELECT *from addnotice where target='$year'||target='TOALL'";
$result=mysqli_query($bd,$sql);	

 if ($result->num_rows > 0) 
 {
  print("<section id='client' class='client-section'>");
  while($row=mysqli_fetch_array($result,MYSQL_NUM))
  {
	if($row[5]==='1')	
	 {
			  print("<div class='print'><p align='right'>$row[6]</p>
	         <h4 align='left'>$row[1]</h4>
	         <p align='left'>$row[3]</p>
	         <h5 align='right'>By:$row[4]</h5>
	         </div>");
	 }
  }
 print("</section>");
}
else
{
	print("<h3 align=center>No Requests are available!!!</h3>");
}

?>
</table>  
</div>

</body></html>



