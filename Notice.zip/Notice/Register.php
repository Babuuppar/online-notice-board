<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BMSCE</title>
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 </head>
 <body>
<?php
if(!isset($_SESSION))
	{
	  session_start();								
	}  
$register="Registered and sent for approval!!!";
$mysql_hostname="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_database="noticeboarddata";
$bd=mysqli_connect($mysql_hostname,$mysql_user,$mysql_password);
if (!$bd)
{
die("Database connection failed!!");
}
else
{
    echo("ok connected");
}
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
//echo("count is one 1");

if($_SERVER["REQUEST_METHOD"] == "POST")
{
$firstname=$_POST['firstname']; 
$lastname=$_POST['lastname']; 
$usertype=$_POST['user'];
$email=$_POST['email'];
$pword=$_POST['password'];
if(isset($_POST['user']))
   $usertype=$_POST['user'];
if(isset($_POST['usn']))
   $uid=$_POST['usn']; 
if(isset($_POST['staffid']))
   $uid=$_POST['staffid'];
if(isset($_POST['designation']))
   $designation=$_POST['designation']; 
if(isset($_POST['sel']))
   $designation=$_POST['sel'];
$SQL="SELECT *from register where uid='$uid'";
$result=mysqli_query($bd,$SQL);
if($row=mysqli_fetch_array($result, MYSQL_NUM)) 
{
    echo "This account is already present!!";
}
else
 {
$sql="Insert into register(fname,lname,usertype,uid,Designation,email,pword) values('$firstname','$lastname','$usertype','$uid','$designation','$email','$pword')";
//echo($sql);
$result=mysqli_query($bd,$sql);
if(!$result)
{
    echo "Record not inserted";
    //header("location: slogin.php");
}
else 
{
    $_SESSION['registered']=$register;
   header('Location:http://localhost/Notice/index.php');
   //echo "Record inserted successfully";
}
 }
}
?>
</body>
</html>
