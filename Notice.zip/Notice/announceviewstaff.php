  <html lang="en"><head>
	<meta charset="utf-8">
	<title>jQuery UI Tabs - Default functionality</title>
	    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/Notifications.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
	<script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
	<script>
	$(function() {
		$( "#tabs" ).tabs();
	});
	</script>
</head>
<body>

<div id="tabs" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
	<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
		<li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-1" aria-labelledby="ui-id-1" aria-selected="false" aria-expanded="false">
		<a href="#tabs-1" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-1">I YEAR</a></li>
		<li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="tabs-2" aria-labelledby="ui-id-2" aria-selected="true" aria-expanded="true">
		<a href="#tabs-2" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-2">II YEAR</a></li>
		<li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="tabs-2" aria-labelledby="ui-id-2" aria-selected="true" aria-expanded="true">
		<a href="#tabs-3" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-3">III YEAR</a></li>
	</ul>
	<div id="tabs-1" aria-labelledby="ui-id-1" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="true" style="display: none;">
<!--<table border="" cellpadding="5%" cellspacing="5%"> --> 
<?php
include("config.php");
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
?>

 <?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$year="I MCA";
$sql="SELECT *from addnotice where target='$year'";
$result=mysqli_query($bd,$sql);
if ($result->num_rows > 0)	
{
  print("<section id='client' class='client-section'><div class='container'>");
  //print("<tr bgcolor=lightblue><th>ANNOUNCEMENT ID<th>TITLE<th>REQUESTED BY<th colspan=3>ACTIONS</tr>");
  while($row=mysqli_fetch_array($result,MYSQL_NUM))
  {
    if($row[5]==='1')	{
		  if($userid==="Ankibabu")
		      $admin="<h5 align='right'><form action='accept.php' class='response' target='_top' name=$row[0] method='post'><input title='Archive' type='submit' value='Archive' name='$row[0]'/></form></h5>";
	      else
			$admin="";
		  print("<div class='print'><h4 align='right'>$row[6]</h4>$admin
	         <h5 align='left'>$row[1]</h5>
	         <p align='left'>$row[3]</p>
	         <h5 align='right'>By:$row[4]</h5>
	         </div>");
		
	}
	//print("<div class='row'><div class='col-md-12'><div class='testimonial-section'> <div class='testimonial'><p>$row[1]$row[3]<div calss='testimonial-people'><form action='accept.php' name='$row[0]' method='post'><input type='submit' value='Hold' name='$row[0]'/><input type='submit' value='Reject' name='$row[0]'/><input type='submit' value='Accept' name='$row[0]'/></form></div> <h5 align='right'>By:$row[4]</h5></div></div></div></div>");
  }
 print("</div></section>");
}
else
{
	print("<h3 align=center>No Requests are available!!!</h3>");
}
//exit();
?>
<!--</table>  -->
</div>
<div id="tabs-2" aria-labelledby="ui-id-2" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="false" style="display: block;">
<table border="" cellpadding="10%" cellspacing="5%">  
 <?php
include("config.php");
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$year="II MCA";
//print("<i class=fa fa-archive aria-hidden=true></i><a href='' align='right' title='Archive'><i class='fa fa-archive' aria-hidden='true'></i></a>");

$sql="SELECT *from addnotice where target='$year'";
$result=mysqli_query($bd,$sql);
if ($result->num_rows > 0) 
{
  print("<section id='client' class='client-section'>");
  while($row=mysqli_fetch_array($result,MYSQL_NUM))
  {
	if($row[5]==='1')	
	{
		if($userid==="Ankibabu")
		  $admin="<h5 align='right'><form action='accept.php' class='response' target='_top' name=$row[0] method='post'><input title='Archive' type='submit' value='Archive' name='$row[0]'/></form></h5>";
	    else
			$admin="";
	    print("<div class='print'><strong><h4 align='right'>$row[6]</h4>$admin<strong>
	         <h5 align='left'>$row[1]</h5></h5>
	         <p align='left'>$row[3]</p>
	         <h5 align='right'>By:$row[4]</h5>
	         </div>");
			 
	 }

		// print("<div class='row'><div class='col-md-12'><div class='testimonial-section'> <div class='testimonial'><p>$row[1]$row[3]<div calss='testimonial-people'><form action='accept.php' name='$row[0]' method='post'><input type='submit' value='Hold' name='$row[0]'/><input type='submit' value='Reject' name='$row[0]'/><input type='submit' value='Accept' name='$row[0]'/></form></div> <h5 align='right'>By:$row[4]</h5></div></div></div></div>");
	    // print("<tr><td>$row[0]</td><td>$row[1]</td><td>$row[4]</td><td><a href=''><a><button type='button' class='btn btn-next' >Accept</button></a></td><td><a><button type='button' class='btn btn-next' >Reject</button></a></td><td><a><button type='button' class='btn btn-next' >Hold</button></a></td></tr>");
  }
 print("</section>");
}
else
{
	print("<h3 align=center>No Requests are available!!!</h3>");
}

//exit();
?>
</table>
</div>
<div id="tabs-3" aria-labelledby="ui-id-2" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="false" style="display: block;">
<table border="" cellpadding="10%" cellspacing="5%">  

 <?php
include("config.php");
$count=0;
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$year="III MCA";
$sql="SELECT *from addnotice where target='$year'";
$result=mysqli_query($bd,$sql);
if ($result->num_rows > 0) 
{
  print("<section id='client' class='client-section'>");
  //print("<tr bgcolor=lightblue><th>ANNOUNCEMENT ID<th>TITLE<th>REQUESTED BY<th colspan=3>ACTIONS</tr>");
  while($row=mysqli_fetch_array($result,MYSQL_NUM))
  {
     if($row[5]==='1')	
	 {
		 if($userid==="Ankibabu")
		  $admin="<h5 align='right'><form action='accept.php' class='response' target='_top' name=$row[0] method='post'><input title='Archive' type='submit' value='Archive' name='$row[0]'/></form></h5>";
	     else
			$admin="";
	     print("<div class='print'><h4 align='right'>$row[6]</h4>$admin
	         <h5 align='left'>$row[1]</h5> <h5 align='right'>$row[5]</h5></h5>
	         <p align='left'>$row[3]</p>
	         <h5 align='right'>By:$row[4]</h5>
	         </div>");
		
	 }
	// print("<div class='row'><div class='col-md-12'><div class='testimonial-section'> <div class='testimonial'><p>$row[1]$row[3]<div calss='testimonial-people'><form action='accept.php' name='$row[0]' method='post'><input type='submit' value='Hold' name='$row[0]'/><input type='submit' value='Reject' name='$row[0]'/><input type='submit' value='Accept' name='$row[0]'/></form></div> <h5 align='right'>By:$row[4]</h5></div></div></div></div>");
  }
  print("</section>");
 }
else
{
	print("<h3 align=center>No announcements are available!!!</h3>");
}
       
?>
</table>
</div>
</div>
</body></html>