<html>
<body>
<?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
//echo("count is one 1");
//echo "HI HOD!!"; 
//echo $_SESSION["id"];
$userid=$_SESSION["id"];
$sql="SELECT fname FROM register WHERE uid='$userid'";
$result=mysqli_query($bd,$sql);
$row=mysqli_fetch_array($result);
echo "<h2 align=right><u>$row[0]</u></h2><hr/>";
//$_SESSION['uservar']=$myusername;
//header("location: smainpage.php");
//exit();
?>     
<h3 align="right"><a href="Logout.php">Logout</a></h3>
</body>
</html>