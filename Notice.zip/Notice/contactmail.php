<?php
require 'PHPMailer/PHPMailerAutoload.php';
function cmail($email,$pmail,$att,$sub,$name)
{
$username=$_POST['name']; 
$phone=$_POST['phone']; 
$emailuser=$_POST['email'];
$message=$_POST['message'];
$mail = new PHPMailer;
//$mail->Host = "ssl://smtp.gmail.com"; 
//$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "bmsmcanotice@gmail.com";                 
$mail->Password = "BMSCE@MCA";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to 
$mail->Port = 587;                                   

$mail->From = "bmsmcanotice@gmail.com";
$mail->FromName = "CONTACTUS-MAIL";

$mail->addAddress($email, $name);
$mail->addAddress($pmail, $name);

$mail->isHTML(true);

$mail->Subject =$name;
$mail->Body = "<b>Name:</b>$username<br/><b>Phone Number:</b></h3>$phone<br/><b>Email:$emailuser</b><br/><b>Message</b><p>$message</p>";

if(!$mail->send()) 
{
    //echo "Mailer Error: " . $mail->ErrorInfo;
	return false;
} 
unset($mail);
return true;
}
$x=cmail("bmsmcanotice@gmail.com","bmsmcanotice@gmail.com","98","e-Notice","e-Notice");
if($x)
{
	header('location:index.html');
	
}
else
	header('location:index.html');

?>