<?php
$mysql_hostname="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_database="noticeboarddata";
$bd=mysqli_connect($mysql_hostname,$mysql_user,$mysql_password);
if(!$bd)
{
die("Database connection failed!!");
}
else
{
    //echo("ok connected");
}
?>
