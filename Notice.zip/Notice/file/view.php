<?php
include 'dbconfig.php';
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>File Uploading With PHP and MySql</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<div id="header">
<label>File Uploading With PHP and MySql</label>
</div>
<div id="body">
	<table width="80%" border="1">
    <tr>
    <th colspan="4">your uploads...<label><a href="index.php">upload new files...</a></label></th>
    </tr>
    <tr>
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>View</td>
    </tr>
    <?php
	$sql="select *from tbl_uploads";
	$result=mysqli_query($bd,$sql);
	while($row=mysqli_fetch_array($result))
	{
       print("<td>$row[1]</td>
        <td>$row[2]</td>
        <td> $row[3]</td>
        <td><a href='uploads/$row[1]' target='_blank'>view file</a></td>
        </tr>");
        
	}
	?>
    </table>
    
</div>
</body>
</html>