   
<!DOCTYPE html>
<html class="no-js">
<head>
    
    <title>Admin</title>
    <link rel="shortcut icon" href="favicon.ico">
    <!--/// Plugin //-->
    <link rel="stylesheet" type="text/css" href="jquery-ui.css" media="all">
    <!--/// Stylesheets //-->
    <link rel="stylesheet" type="text/css" href="style.css" media="all">
	<link href="responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />  
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
	
    <!--/// CORE scripts always load first //-->
    <script src="jquery.js"></script>
</head>	
<body onLoad="document.getElementById('link').click();">
<table border="" cellpadding="5%" cellspacing="5%">  
 <tr bgcolor="lightblue"><th>USER ID<th>NAME<th>USERTYPE</tr>
 <?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
$userid=$_SESSION["id"];
$sql="SELECT *from register WHERE verified=0";
$result=mysqli_query($bd,$sql);
while($row=mysqli_fetch_array($result,MYSQL_NUM))
 {
    print("<a href=''><tr><td>$row[3]</td><td>$row[0].$row[1]</td><td>$row[2]</td></tr></a>");
 }

//exit();
?>
</table>  
</div> 
   <script type="text/javascript" src="jquery.form.js"></script><!-- Social Icons -->	
    <!--/// PLUGINS_DEPENDENCY always load after CORE but before PLUGINS //-->
    <script src="theme.js"></script>
	<script src="smoothscroll.js" type="text/javascript"></script>
	<script src="responsive-tabs.min.js" type="text/javascript"></script>
</body>
</html>