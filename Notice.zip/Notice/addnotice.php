<?php
session_start();
$mysql_hostname="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_database="noticeboarddata";
$bd=mysqli_connect($mysql_hostname,$mysql_user,$mysql_password);
if (!$bd)
{
die("Database connection failed!!");
}
else
{
    echo("Connected");
}
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
//echo("count is one 1");
$approved=0; 
if($_SERVER["REQUEST_METHOD"] == "POST")
{

$title=$_POST['title']; 
$target=$_POST['target'];
$description=$_POST['description'];
$AI=array_keys($_POST);
$action=$_POST['post']; 
$id=$_SESSION['id'];
$SQL1="SELECT fname,Designation,lname from register where uid='$id'";
$result1=mysqli_query($bd,$SQL1);
$row=mysqli_fetch_array($result1,MYSQL_NUM);
$requested=$row[0]." ".$row[2];
if($_SESSION['id']==="Ankibabu")
{
	  $approved=1;
	  $requested=$_SESSION['id'];
	  
}
if($row[1]==="HOD")
  $approved=1; 
else if($action==="POST")
{
	  $approved=3;
}
  date_default_timezone_set('Asia/Kolkata');
  $datetimee=date('Y-m-d h:m',time());
  $sql="insert into addnotice(title,target,description,requested,approved,created) values('$title','$target','$description','$requested','$approved','$datetimee')";
  $result=mysqli_query($bd,$sql);
  if(!$result)
  {
      echo "Record not inserted";
  }
  else 
  {
	 $link="Location:".$_SESSION["link"];
	 header($link);
     //echo $action;
   
  }
 }
?>