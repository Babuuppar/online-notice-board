<?php
require 'PHPMailer/PHPMailerAutoload.php';
function cmail($email,$pmail,$att,$sub,$name)
{
$mail = new PHPMailer;
//$mail->Host = "ssl://smtp.gmail.com"; 
//$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "bmsmcanotice@gmail.com";                 
$mail->Password = "BMSCE@MCA";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to 
$mail->Port = 587;                                   

$mail->From = "bmsmcanotice@gmail.com";
$mail->FromName = "E-NOTICEMCA";

$mail->addAddress($email, $name);
$mail->addAddress($pmail, $name);

$mail->isHTML(true);

$mail->Subject = "Registered successfully";
$mail->Body = "<b>Your account has been sent for approval by the higher authority ,soon you will get a verification mail</b>";

if(!$mail->send()) 
{
    //echo "Mailer Error: " . $mail->ErrorInfo;
	return false;
} 
unset($mail);
return true;
}
$x=cmail("bmsmcanotice@gmail.com","bmsmcanotice@gmail.com","98","e-Notice","e-Notice");
/*if($x)
{
	echo "Mail Sent";
	
}
else
	echo "mail not sent";
*/
?>