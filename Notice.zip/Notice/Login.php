<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BMSCE</title>
        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
 </head>
 
 <body>
<?php
ob_start();
error_reporting(0);
session_start();
$message="Invalid username or password!!!";
$mysql_hostname="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_database="noticeboarddata";
$bd=mysqli_connect($mysql_hostname,$mysql_user,$mysql_password);
if (!$bd)
{
die("Database connection failed!!");
}
else
{
    echo("ok connected");
}
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
//echo("count is one 1");

if($_SERVER["REQUEST_METHOD"]=="POST")
{
$i=0;
  $uid=$_POST['userid']; 
  $password=$_POST['password']; 
  $SQL="SELECT *from register where uid='$uid' and pword='$password'";
  $result=mysqli_query($bd,$SQL);
  $SQL1="SELECT usertype,Designation,verified from register where uid='$uid' and pword='$password'";
  $result1=mysqli_query($bd,$SQL1);
  $SQL2="SELECT *from admin where Admin='$uid' and pword='$password'";
  $result2=mysqli_query($bd,$SQL2);
  if(mysqli_num_rows($result2)===1) 
    {
		$_SESSION["id"]=$uid;
		header('Location:admin.php');
	    //echo "Login successful!!"; 
	    //break;
    }
  else{
  while($row=mysqli_fetch_array($result1))
  {
	$i++;
	$_SESSION["id"]=$uid;
	$user=$row[0];
	$designation=$row[1];
    if(mysqli_num_rows($result)===1&&$designation==="HOD") 
    {
        if($row[2]==='1')
		{
			header('Location:hod.php');
		}
		else
		{
			$_SESSION['message']="Your account is not approved yet!!";
			header('Location:http://localhost/Notice/index.php');
		}
	    //echo "Login successful!!"; 
	   // break;
    }
	else if(mysqli_num_rows($result)===1&&$user==="student") 
    {
      if($row[2]==='1')
		{
			header('Location:student.php');
		}
		else
		{
			$_SESSION['message']="Your account is not approved yet!!";
			header('Location:http://localhost/Notice/index.php');
		}      
	   //echo "Login successful!!";
	   //break;
   }
   else if(mysqli_num_rows($result)===1&&$user==="staff") 
   {      
	  if($row[2]==='1')
		{
			
			header('Location:staff.php');
		}
		else
		{
			$_SESSION['message']="Your account is not approved yet!!";
			header('Location:http://localhost/Notice/index.php');
		}     
	   //echo "Login successful!!";
	  // break;
   }	  
   
  else
   {
      header('Location:http://localhost:8000/Notice/index.html');
      echo "Your not yet registered!!Please register!!";
	  //break;
   }
   
}

if($i<=0)
{
	  $_SESSION['message']=$message;
      header('Location:http://localhost/Notice/index.php');
	 //echo "Failed";
}

}	
}

?>
</body>
</html>
