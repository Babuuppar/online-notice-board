<?php
include("config.php");
session_start();
mysqli_select_db($bd,$mysql_database) or die("Database selection failed!!");
//echo("count is one 1");
//echo "HI HOD!!"; 
//echo $_SESSION["id"];
$userid=$_SESSION["id"];
$sql="SELECT fname FROM register WHERE uid='$userid'";
$result=mysqli_query($bd,$sql);
$row=mysqli_fetch_array($result);
//echo "<h3 align=right>$row[0]</h3>";
//$_SESSION['uservar']=$myusername;
//header("location: smainpage.php");
//exit();
?>   
<!DOCTYPE html>
<html class="no-js">
<head>
    
    <title>student page</title>
    <link rel="shortcut icon" href="favicon.ico">
    <!--/// Plugin //-->
    <link rel="stylesheet" type="text/css" href="jquery-ui.css" media="all">
    <!--/// Stylesheets //-->
    <link rel="stylesheet" type="text/css" href="style.css" media="all">
	<link href="responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />  
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="form.css" type="text/css"/>
        <script type="text/javascript" src="form.js"></script>
	
    <!--/// CORE scripts always load first //-->
    <script src="jquery.js"></script>
</head>	
<body onLoad="document.getElementById('link').click();">
    <section id="wrapper">
<nav class="navbar navbar-inverse navbar-no-bg" role="navigation">
			<div class="container">
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="top-navbar-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<span class="li-social">
							<a href="" target="_blank"><?php print "$row[0]";?></a>
							<a href="Logout.php" target="Logout.php"  ">Logout</a>
							</span>
						</li>
					</ul>
				</div>
			</div>
</nav>   	  	 
            <h1 class="heading">STUDENT</h1>
            <h3 class="iternal_h3"></h3>
            <div class="container responsive-tabs-default">
                <div class="internal_navi">
                    <ul class="responsive-tabs">
                        <li><a href="#view" target="_self">ANNOUNCEMENTS</a></li>
                    </ul>
                </div>
			<div class="responsive-tabs-content bm-larger">
				<div id="view" class="responsive-tabs-panel">
					<div class="freme_box">
						<iframe src="announceviewstudent.php" class="demo-frame"></iframe>
            		</div>
				</div>
			</div>
		</div>
         
        </div> <!--/// .container //-->
        
        		<footer id="main_footer">
        	<div class="container row">
            	<div class="span_1_of_2">
                	&copy; Copyrights 2017. All rights reserved.
                </div>
            	<!--<div class="span_1_of_2">
                	<div align="right">Designed By: <a href="http://www.webstreaks.com/" target="_blank">Webstreaks.com</a></div>
                </div>-->
            </div>
        </footer>        
    </section> <!--/// #wrapper //-->
   <script type="text/javascript" src="jquery.form.js"></script><!-- Social Icons -->	
    <!--/// PLUGINS_DEPENDENCY always load after CORE but before PLUGINS //-->
    <script src="theme.js"></script>
	<script src="smoothscroll.js" type="text/javascript"></script>
	<script src="responsive-tabs.min.js" type="text/javascript"></script>
</body>
</html>